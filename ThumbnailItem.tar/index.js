// Write your code here.
import './index.css'

const ThumbnailItem = props => {
  const {imageDetails, thumbnail, isActive} = props
  const {thumbnailUrl, thumbnailAltText, id} = imageDetails
  const clickImage = () => {
    thumbnail(id)
  }
  return (
    <li>
      <button type="button" className="button">
        <img src={thumbnailUrl} alt={thumbnailAltText} onClick={clickImage} />
      </button>
    </li>
  )
}

export default ThumbnailItem
